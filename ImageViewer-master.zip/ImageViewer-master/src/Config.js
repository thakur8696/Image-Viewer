export const properties = {
    dpUrl: "https://scontent-iad3-1.cdninstagram.com/v/t51.29350-15/192178301_773030510062147_6420479614626111894_n.jpg?_nc_cat=101&ccb=1-3&_nc_sid=8ae9d6&_nc_ohc=OG9F6vUS-LoAX-9jme2&_nc_ht=scontent-iad3-1.cdninstagram.com&oh=1ac53e5a4b52f29a34a7b8b2dfa07137&oe=60B612B6",
    username: "prateekmehta.dsd19",
    accessToken: "IGQVJXcHk2TjdfVk5reGZAYaGFJRUJkSDJTUFdYZAUFLWjRHRE5uZAUJ6cklaNXhJYVhJU2dlUVh6V2RMTW1Hcm5pVDJMWk1KS3UwMlMxa3hEZAW1WM2R4ZAGpBMk50ZAFU0RDFVMVI3UDJkRmcwRk1LdTlZATgZDZD",
    fullName: "Prateek Mehta",
    hashTags: "#upgrad #upgradproject #reactjs"
    /*
    username: "upgrad",
    password: "upgrad"
    */ // Hard-Coded in Login.js as per instructions.
};